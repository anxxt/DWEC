/**
 * Mensaje Hola Mundo para fichero ejemplo2.html
 * @author Antonio García García
 */

alert("Hola Mundo");